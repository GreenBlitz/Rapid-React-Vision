"""
UART Constants
"""

DEFAULT_ALGO: str = "No Algorithm"
BAUD_RATE: int = 115200
DOUBLE_SIZE: int = 8
PING_SIZE: int = 5
